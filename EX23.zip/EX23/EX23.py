import requests
from telegram.ext import Updater, CommandHandler, MessageHandler, Filters


class Music:
    def __init__(self, artistName, trackName, trackPrice, trackViewUrl, description, artworkUrl100):
        self.artistName = artistName
        self.trackName = trackName
        self.trackPrice = trackPrice
        self.trackViewUrl = trackViewUrl
        self.description = description
        self.artworkUrl100 = artworkUrl100

    # def __str__(self):
    #     return (f"Artist name: {self.artistName}\nTrack Name: {self.trackName}\nTrack price: {self.trackPrice}\nTrack URL: {self.trackViewUrl}\n"
    #             f"Description: {self.description}")


class Fetcher:

    @staticmethod
    def musicFetcher(term):
        url = "https://itunes.apple.com/search"
        params = {'entity': 'song',
                  'term': term,
                  'limit': 10}
        response = requests.get(url, params=params)
        if response.status_code == 200:
            music_item = response.json()
            music_items = music_item['results']
            music_list = []

            for item in music_items:
                music_obj = Music(
                    item.get('artistName', 'Fail'),
                    item.get('trackName', 'Fail'),
                    item.get('trackPrice', 'Fail'),
                    item.get('trackViewUrl', 'Fail'),
                    item.get('description', 'Fail'),
                    item.get('artworkUrl100', 'Fail')

                )
                music_list.append(music_obj)
            return music_list
        else:
            print('Failed')

class TelBot:
    def __init__(self):
        self.music_fetcher = Fetcher()
    def start(self, update, context):
        update.message.reply_text('Hello Dear, send artist name: ')

    def handle_msg(self, update, context):
        user_input = update.message.text
        recommendations = self.music_fetcher.musicFetcher(user_input)
        for music in recommendations:
            description = music.description
            if len(description) > 500:
                description = description[:500] + '...'
            response = (f"\n\n*Name of the Music Track:* {music.trackName}\n\n"
                        f"*Artist(s):* {music.artistName}\n\n"
                        f"*Track Price:* {music.trackPrice}\n\n"
                        f"*More Info:* [Link]({music.trackViewUrl})\n{95 * '-'}\n"
                        f"*Description:* {description}\n\n\n")
            context.bot.send_photo(chat_id=update.effective_chat.id, photo=music.artworkUrl100, caption=response,
                                   parse_mode='Markdown')

        if not recommendations:
            update.message.reply_text("No books found.")


if __name__ == "__main__":
    TOKEN = '6762311644:AAHTy3M1rycDLmvKiP20-EALH-7cfTP4C0s'
    updater = Updater(TOKEN, use_context=True)
    db = updater.dispatcher
    bot_handler = TelBot()
    db.add_handler(CommandHandler("start", bot_handler.start))
    db.add_handler(MessageHandler(Filters.text, bot_handler.handle_msg))
    updater.start_polling()
    updater.idle()
